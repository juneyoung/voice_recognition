package edu.cmu.sphinx.demo.raw;

import java.net.MalformedURLException;
import java.net.URISyntaxException;

/**
 * Created by IntelliJ IDEA.
 * User: peter
 * Date: Jan 12, 2010
 * Time: 4:09:25 PM
 * To change this template use File | Settings | File Templates.
 * <p/>
 * Copyright 1999-2004 Carnegie Mellon University.
 * Portions Copyright 2004 Sun Microsystems, Inc.
 * Portions Copyright 2004 Mitsubishi Electric Research Laboratories.
 * All Rights Reserved.  Use is subject to license terms.
 * <p/>
 * See the file "license.terms" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 */
public class LatticeConfiguration extends HelloNGramConfiguration {
    public LatticeConfiguration() throws MalformedURLException, URISyntaxException, ClassNotFoundException {
    }

}
