package javax.speech;

//Comp. 2.0.6

public interface EnginePropertyListener {
    void propertyUpdate(EnginePropertyEvent event);
}
