/**
 * 
 */
package org.jvoicexml.jsapi2.jse;

import javax.sound.sampled.AudioFormat;
import javax.speech.Engine;

import junit.framework.Assert;

import org.junit.Test;

/**
 * Test cases for {@link AudioFormatConverter}.
 * @author Dirk Schnelle-Walka
 *
 */
public class AudioFormatConverterTest {
}
